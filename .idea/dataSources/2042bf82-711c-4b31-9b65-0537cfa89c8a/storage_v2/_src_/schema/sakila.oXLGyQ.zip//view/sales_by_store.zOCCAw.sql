CREATE VIEW sales_by_store AS
  SELECT
    concat(`c`.`city`, ',', `cy`.`country`)        AS `store`,
    concat(`m`.`first_name`, ' ', `m`.`last_name`) AS `manager`,
    sum(`p`.`amount`)                              AS `total_sales`
  FROM (((((((`sakila`.`payment` `p`
    JOIN `sakila`.`rental` `r` ON ((`p`.`rental_id` = `r`.`rental_id`))) JOIN `sakila`.`inventory` `i`
      ON ((`r`.`inventory_id` = `i`.`inventory_id`))) JOIN `sakila`.`store` `s`
      ON ((`i`.`store_id` = `s`.`store_id`))) JOIN `sakila`.`address` `a`
      ON ((`s`.`address_id` = `a`.`address_id`))) JOIN `sakila`.`city` `c` ON ((`a`.`city_id` = `c`.`city_id`))) JOIN
    `sakila`.`country` `cy` ON ((`c`.`country_id` = `cy`.`country_id`))) JOIN `sakila`.`staff` `m`
      ON ((`s`.`manager_staff_id` = `m`.`staff_id`)))
  GROUP BY `s`.`store_id`
  ORDER BY `cy`.`country`, `c`.`city`;

